/**
 * Shared constants
 */

export const APP_NAME = 'Pixel Pets Reborn x Remeged';
export const APP_VERSION = '1.0.0';
















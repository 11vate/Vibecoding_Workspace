/// <reference types="vite/client" />
















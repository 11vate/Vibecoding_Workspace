/**
 * Sprite Generator Service
 * Generates procedural sprites for pets with caching support (in-memory + IndexedDB)
 */

import type { PetFamily } from '@/shared/types/family';
import type { Pet } from '@/domain/entities/Pet';
import { openDatabase } from '../persistence/schema';
import type { SpriteDTO } from '../persistence/schema';

export interface SpriteGenerationParams {
  family: PetFamily;
  visualTags: string[];
  rarity: number;
  colorMutation?: { r: number; g: number; b: number };
  glowColor?: string;
  width?: number;
  height?: number;
  animationState?: 'idle' | 'attack' | 'hit' | 'ultimate' | 'death';
}

export interface GeneratedSprite {
  dataUrl: string;
  width: number;
  height: number;
  cacheKey: string;
  animationStates?: {
    idle?: string;
    attack?: string;
    hit?: string;
    ultimate?: string;
    death?: string;
  };
}

/**
 * Family-based color palettes
 */
const FAMILY_PALETTES: Record<PetFamily, string[]> = {
  PYRO_KIN: ['#FF6B35', '#F7931E', '#FFD23F', '#EE4B2B', '#C21807'],
  AQUA_BORN: ['#00A8E8', '#007EA7', '#003459', '#80D4FF', '#4A90E2'],
  TERRA_FORGED: ['#8B7355', '#A0826D', '#6B5840', '#C4A676', '#9D7C52'],
  VOLT_STREAM: ['#FFD700', '#FFA500', '#FF6B00', '#FFEB3B', '#FFC107'],
  SHADOW_VEIL: ['#2C1810', '#1A1A1A', '#4A4A4A', '#6B6B6B', '#8B8B8B'],
  LUMINA: ['#FFFFFF', '#FFFACD', '#FFE4B5', '#F0F8FF', '#E6E6FA'],
  STEEL_WORKS: ['#708090', '#778899', '#B0C4DE', '#C0C0C0', '#D3D3D3'],
  ARCANE_RIFT: ['#9370DB', '#8A2BE2', '#9400D3', '#BA55D3', '#DA70D6'],
  AERO_FLIGHT: ['#87CEEB', '#87CEFA', '#B0E0E6', '#E0F6FF', '#F0F8FF'],
  WEIRDOS: ['#FF1493', '#00FF00', '#FF00FF', '#00FFFF', '#FFFF00'],
};

/**
 * Sprite Generator
 * Generates procedural pixel art sprites using canvas
 */
export class SpriteGenerator {
  private static readonly DEFAULT_WIDTH = 128; // Upgraded from 64
  private static readonly DEFAULT_HEIGHT = 128; // Upgraded from 64
  private cache: Map<string, GeneratedSprite> = new Map();

  /**
   * Generate sprite for a Pet entity (with all animation states)
   */
  async generateSpriteForPet(pet: Pet): Promise<string> {
    const params: SpriteGenerationParams = {
      family: pet.family,
      visualTags: pet.appearance.visualTags,
      rarity: pet.rarity,
      colorMutation: pet.appearance.colorMutation,
      glowColor: pet.appearance.glowColor,
    };

    // Generate all animation states
    const animationStates: Record<string, string> = {};
    
    // Generate idle (default)
    const idleSprite = await this.generateSprite({ ...params, animationState: 'idle' });
    animationStates.idle = idleSprite.dataUrl;
    
    // Generate other animation states
    const states: Array<'attack' | 'hit' | 'ultimate' | 'death'> = ['attack', 'hit', 'ultimate', 'death'];
    for (const state of states) {
      const stateSprite = await this.generateSprite({ ...params, animationState: state });
      animationStates[state] = stateSprite.dataUrl;
    }

    // Return idle as default, but store all states
    return idleSprite.dataUrl;
  }

  /**
   * Generate all animation states for a pet
   */
  async generateAllAnimationStates(pet: Pet): Promise<GeneratedSprite['animationStates']> {
    const params: SpriteGenerationParams = {
      family: pet.family,
      visualTags: pet.appearance.visualTags,
      rarity: pet.rarity,
      colorMutation: pet.appearance.colorMutation,
      glowColor: pet.appearance.glowColor,
    };

    const animationStates: GeneratedSprite['animationStates'] = {};
    
    const states: Array<'idle' | 'attack' | 'hit' | 'ultimate' | 'death'> = ['idle', 'attack', 'hit', 'ultimate', 'death'];
    for (const state of states) {
      const sprite = await this.generateSprite({ ...params, animationState: state });
      animationStates[state] = sprite.dataUrl;
    }

    return animationStates;
  }

  /**
   * Generate sprite from parameters
   */
  async generateSprite(params: SpriteGenerationParams): Promise<GeneratedSprite> {
    // Create cache key
    const cacheKey = this.createCacheKey(params);

    // Check in-memory cache
    const cached = this.cache.get(cacheKey);
    if (cached) {
      return cached;
    }

    // Check IndexedDB cache
    const dbCached = await this.getCachedSpriteFromDB(cacheKey);
    if (dbCached) {
      // Store in memory cache for faster access
      this.cache.set(cacheKey, dbCached);
      return dbCached;
    }

    // Generate new sprite
    const sprite = await this.generateProceduralSprite(params);

    // Cache in memory
    this.cache.set(cacheKey, sprite);

    // Cache in IndexedDB
    await this.cacheSpriteInDB(cacheKey, sprite, params.visualTags);

    return sprite;
  }

  /**
   * Get cached sprite from IndexedDB
   */
  private async getCachedSpriteFromDB(cacheKey: string): Promise<GeneratedSprite | null> {
    try {
      const db = await openDatabase();
      const dto = await db.get('sprites', cacheKey);
      
      if (!dto) {
        return null;
      }

      return {
        dataUrl: dto.spriteData,
        width: SpriteGenerator.DEFAULT_WIDTH,
        height: SpriteGenerator.DEFAULT_HEIGHT,
        cacheKey: dto.id,
      };
    } catch (error) {
      console.warn('[SpriteGenerator] Failed to read from IndexedDB cache:', error);
      return null;
    }
  }

  /**
   * Cache sprite in IndexedDB
   */
  private async cacheSpriteInDB(
    cacheKey: string,
    sprite: GeneratedSprite,
    visualTags: string[]
  ): Promise<void> {
    try {
      const db = await openDatabase();
      const dto: SpriteDTO = {
        id: cacheKey,
        spriteData: sprite.dataUrl,
        visualTags,
        createdAt: Date.now(),
      };
      
      await db.put('sprites', dto);
    } catch (error) {
      console.warn('[SpriteGenerator] Failed to cache sprite in IndexedDB:', error);
      // Don't throw - caching is optional, generation succeeded
    }
  }

  /**
   * Create cache key from parameters
   */
  private createCacheKey(params: SpriteGenerationParams): string {
    const tags = params.visualTags.sort().join(',');
    const mutation = params.colorMutation
      ? `${params.colorMutation.r},${params.colorMutation.g},${params.colorMutation.b}`
      : 'none';
    const glow = params.glowColor || 'none';
    const animState = params.animationState || 'idle';
    return `${params.family}-${tags}-${params.rarity}-${mutation}-${glow}-${animState}`;
  }

  /**
   * Generate procedural sprite
   */
  private async generateProceduralSprite(
    params: SpriteGenerationParams
  ): Promise<GeneratedSprite> {
    const width = params.width || SpriteGenerator.DEFAULT_WIDTH;
    const height = params.height || SpriteGenerator.DEFAULT_HEIGHT;

    // Create canvas
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      throw new Error('Failed to get canvas context');
    }

    // Get base colors from family palette
    const palette = FAMILY_PALETTES[params.family];
    const baseColor = this.selectBaseColor(palette, params.rarity);

    // Apply color mutation if present
    let finalColor = baseColor;
    if (params.colorMutation) {
      finalColor = this.applyColorMutation(baseColor, params.colorMutation);
    }

    // Generate sprite based on visual tags and animation state
    this.drawSprite(ctx, width, height, finalColor, params.visualTags, params.rarity, params.animationState || 'idle');

    // Apply glow effect if present
    if (params.glowColor) {
      this.applyGlow(ctx, width, height, params.glowColor);
    }

    // Convert to data URL
    const dataUrl = canvas.toDataURL('image/png');

    return {
      dataUrl,
      width,
      height,
      cacheKey: this.createCacheKey(params),
    };
  }

  /**
   * Select base color from palette based on rarity
   */
  private selectBaseColor(palette: string[], rarity: number): string {
    // Higher rarity uses brighter/more saturated colors
    const index = Math.min(Math.floor(rarity / 2), palette.length - 1);
    return palette[index] || palette[0];
  }

  /**
   * Apply color mutation to base color
   */
  private applyColorMutation(
    baseColor: string,
    mutation: { r: number; g: number; b: number }
  ): string {
    // Parse base color
    const hex = baseColor.replace('#', '');
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);

    // Apply mutation (weighted blend)
    const newR = Math.round(r * 0.7 + mutation.r * 0.3);
    const newG = Math.round(g * 0.7 + mutation.g * 0.3);
    const newB = Math.round(b * 0.7 + mutation.b * 0.3);

    return `#${newR.toString(16).padStart(2, '0')}${newG.toString(16).padStart(2, '0')}${newB.toString(16).padStart(2, '0')}`;
  }

  /**
   * Draw sprite based on visual tags and animation state
   */
  private drawSprite(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    color: string,
    tags: string[],
    rarity: number,
    animationState: 'idle' | 'attack' | 'hit' | 'ultimate' | 'death' = 'idle'
  ): void {
    // Clear canvas
    ctx.fillStyle = 'transparent';
    ctx.fillRect(0, 0, width, height);

    // Determine shape based on tags
    const isRound = tags.includes('round') || tags.includes('spherical');
    const isAngular = tags.includes('angular') || tags.includes('sharp');
    const isFloating = tags.includes('floating') || tags.includes('ethereal');
    const hasWings = tags.includes('winged') || tags.includes('flying');
    const isLarge = tags.includes('large') || tags.includes('massive');

    const size = isLarge ? Math.min(width, height) * 0.8 : Math.min(width, height) * 0.6;
    let x = width / 2;
    let y = height / 2 - (isFloating ? size * 0.2 : 0);
    
    // Apply animation state transformations
    ctx.save();
    switch (animationState) {
      case 'attack':
        // Lean forward and scale up slightly
        ctx.translate(x, y);
        ctx.scale(1.1, 1.1);
        ctx.translate(-x, -y);
        x += size * 0.1; // Shift forward
        break;
      case 'hit':
        // Shrink and shift back
        ctx.translate(x, y);
        ctx.scale(0.9, 0.9);
        ctx.translate(-x, -y);
        x -= size * 0.05;
        break;
      case 'ultimate':
        // Scale up significantly with glow
        ctx.translate(x, y);
        ctx.scale(1.2, 1.2);
        ctx.translate(-x, -y);
        break;
      case 'death':
        // Shrink and fade
        ctx.translate(x, y);
        ctx.scale(0.7, 0.7);
        ctx.translate(-x, -y);
        ctx.globalAlpha = 0.5;
        break;
      case 'idle':
      default:
        // Subtle idle animation (slight float)
        y += Math.sin(Date.now() / 1000) * 2;
        break;
    }

    // Draw main body
    ctx.fillStyle = color;
    if (isRound) {
      // Circular/round shape
      ctx.beginPath();
      ctx.arc(x, y, size / 2, 0, Math.PI * 2);
      ctx.fill();
    } else if (isAngular) {
      // Angular/geometric shape
      const points = 6;
      const angleStep = (Math.PI * 2) / points;
      ctx.beginPath();
      for (let i = 0; i < points; i++) {
        const angle = i * angleStep - Math.PI / 2;
        const px = x + (size / 2) * Math.cos(angle);
        const py = y + (size / 2) * Math.sin(angle);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
    } else {
      // Default oval shape
      ctx.beginPath();
      ctx.ellipse(x, y, size / 2, size / 1.5, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Draw wings if present
    if (hasWings) {
      ctx.fillStyle = this.adjustBrightness(color, 0.8);
      const wingSize = size * 0.4;
      // Left wing
      ctx.beginPath();
      ctx.ellipse(x - size * 0.4, y, wingSize / 2, wingSize, -0.3, 0, Math.PI * 2);
      ctx.fill();
      // Right wing
      ctx.beginPath();
      ctx.ellipse(x + size * 0.4, y, wingSize / 2, wingSize, 0.3, 0, Math.PI * 2);
      ctx.fill();
    }

    // Add detail based on rarity
    if (rarity >= 3) {
      // Add highlights
      ctx.fillStyle = this.adjustBrightness(color, 1.3);
      ctx.beginPath();
      ctx.arc(x - size * 0.1, y - size * 0.2, size * 0.1, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Restore canvas state after animation transformations
    ctx.restore();
  }

  /**
   * Apply glow effect
   */
  private applyGlow(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    glowColor: string
  ): void {
    // Create a copy of the canvas with glow effect
    const imageData = ctx.getImageData(0, 0, width, height);
    const data = imageData.data;

    // Simple glow: brighten edges
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const index = (y * width + x) * 4;
        const alpha = data[index + 3];

        if (alpha > 0) {
          // Add glow color as overlay
          const glowR = parseInt(glowColor.substring(1, 3), 16);
          const glowG = parseInt(glowColor.substring(3, 5), 16);
          const glowB = parseInt(glowColor.substring(5, 7), 16);

          // Blend glow with existing color
          data[index] = Math.min(255, data[index] + glowR * 0.2);
          data[index + 1] = Math.min(255, data[index + 1] + glowG * 0.2);
          data[index + 2] = Math.min(255, data[index + 2] + glowB * 0.2);
        }
      }
    }

    ctx.putImageData(imageData, 0, 0);
  }

  /**
   * Adjust color brightness
   */
  private adjustBrightness(color: string, factor: number): string {
    const hex = color.replace('#', '');
    const r = Math.min(255, Math.round(parseInt(hex.substring(0, 2), 16) * factor));
    const g = Math.min(255, Math.round(parseInt(hex.substring(2, 4), 16) * factor));
    const b = Math.min(255, Math.round(parseInt(hex.substring(4, 6), 16) * factor));

    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
  }

  /**
   * Clear in-memory cache
   */
  clearCache(): void {
    this.cache.clear();
  }

  /**
   * Clear IndexedDB cache
   */
  async clearDBCache(): Promise<void> {
    try {
      const db = await openDatabase();
      await db.clear('sprites');
    } catch (error) {
      console.warn('[SpriteGenerator] Failed to clear IndexedDB cache:', error);
    }
  }

  /**
   * Get cache size
   */
  getCacheSize(): number {
    return this.cache.size;
  }
}


/**
 * Seed Service
 * Initializes the database with base pets, abilities, and initial player data
 */

import { openDatabase } from '../persistence/schema';
import { BasePetRepository } from '../persistence/repositories/BasePetRepository';
import { AbilityRepository } from '../persistence/repositories/AbilityRepository';
import { PlayerRepository } from '../persistence/repositories/PlayerRepository';
import { StoneRepository } from '../persistence/repositories/StoneRepository';
import { generateBasePet } from './BasePetGenerator';
import { AbilityGenerator } from '@/domain/services/AbilityGenerator';
import { AbilityTemplateLibrary } from '@/domain/services/AbilityTemplate';
import { StoneGenerator } from '@/domain/services/StoneGenerator';
import type { Ability } from '@/domain/entities/Ability';
import { PetFamily } from '@/shared/types/family';
import { Rarity } from '@/shared/types/rarity';
import { RARITY_CONFIG } from '@/shared/types/rarity';
import { StoneType, StoneTier } from '@/domain/entities/Stone';

const SEED_VERSION_KEY = 'seed_version';
const CURRENT_SEED_VERSION = 1;

/**
 * Check if database needs seeding
 */
export async function needsSeeding(): Promise<boolean> {
  try {
    const db = await openDatabase();
    const storedVersion = await db.get('sprites', SEED_VERSION_KEY);
    
    // If no version stored, needs seeding
    if (!storedVersion) {
      return true;
    }
    
    // Check if version matches
    const version = (storedVersion as any)?.seedVersion;
    if (version !== CURRENT_SEED_VERSION) {
      return true;
    }
    
    // Check if we have base pets and abilities
    const basePetCount = await db.count('basePets');
    const abilityCount = await db.count('abilities');
    
    // Need at least some base pets and abilities
    return basePetCount === 0 || abilityCount === 0;
  } catch (error) {
    console.error('[SeedService] Error checking if seeding needed:', error);
    return true;
  }
}

/**
 * Seed all abilities from templates
 */
async function seedAbilities(): Promise<Map<string, Ability>> {
  console.log('[SeedService] Seeding abilities...');
  const abilityRepository = new AbilityRepository();
  const abilityMap = new Map<string, Ability>();
  
  // Get all templates from the library
  const templates = AbilityTemplateLibrary.getAllTemplates();
  
  // Generate abilities from templates for each rarity that can use them
  const rarities = [
    Rarity.BASIC,
    Rarity.RARE,
    Rarity.SR,
    Rarity.LEGENDARY,
    Rarity.MYTHIC,
  ];
  
  for (const template of templates) {
    // Generate ability for each applicable rarity
    const applicableRarities = template.rarity 
      ? rarities.filter(r => r >= template.rarity!)
      : rarities;
    
    for (const rarity of applicableRarities) {
      try {
        const ability = AbilityGenerator.generateFromTemplate(template, rarity);
        await abilityRepository.save(ability);
        abilityMap.set(ability.id, ability);
      } catch (error) {
        console.warn(`[SeedService] Failed to generate ability ${template.name} for rarity ${rarity}:`, error);
      }
    }
  }
  
  // Also generate some random abilities to ensure we have enough
  for (let i = 0; i < 50; i++) {
    const rarity = rarities[Math.floor(Math.random() * rarities.length)];
    const types: ('active' | 'passive' | 'ultimate')[] = ['active', 'passive', 'ultimate'];
    const type = types[Math.floor(Math.random() * types.length)] as any;
    
    try {
      const ability = AbilityGenerator.generateRandom(type, undefined, rarity);
      if (!abilityMap.has(ability.id)) {
        await abilityRepository.save(ability);
        abilityMap.set(ability.id, ability);
      }
    } catch (error) {
      // Skip if generation fails
    }
  }
  
  console.log(`[SeedService] Seeded ${abilityMap.size} abilities`);
  return abilityMap;
}

/**
 * Seed base pets with proper ability IDs
 */
async function seedBasePets(abilityMap: Map<string, Ability>): Promise<void> {
  console.log('[SeedService] Seeding base pets...');
  const basePetRepository = new BasePetRepository();
  
  // Organize abilities by type
  const passiveAbilities: string[] = [];
  const activeAbilities: string[] = [];
  const ultimateAbilities: string[] = [];
  
  abilityMap.forEach((ability, id) => {
    if (ability.type === 'passive') {
      passiveAbilities.push(id);
    } else if (ability.type === 'active') {
      activeAbilities.push(id);
    } else if (ability.type === 'ultimate') {
      ultimateAbilities.push(id);
    }
  });
  
  // Generate base pets
  const families = Object.values(PetFamily);
  const rarities: Rarity[] = [
    Rarity.BASIC,
    Rarity.RARE,
    Rarity.SR,
    Rarity.LEGENDARY,
    Rarity.MYTHIC,
  ];
  const distribution = [5, 3, 3, 2, 2];
  
  let totalSeeded = 0;
  
  for (const family of families) {
    let petIndex = 0;
    
    for (let rarityIndex = 0; rarityIndex < rarities.length; rarityIndex++) {
      const rarity = rarities[rarityIndex];
      const count = distribution[rarityIndex];
      const config = RARITY_CONFIG[rarity];
      
      for (let i = 0; i < count; i++) {
        // Select random abilities
        const passiveIds: string[] = [];
        const activeIds: string[] = [];
        
        // Add passive abilities
        for (let j = 0; j < config.passiveCount && passiveAbilities.length > 0; j++) {
          const randomId = passiveAbilities[Math.floor(Math.random() * passiveAbilities.length)];
          if (!passiveIds.includes(randomId)) {
            passiveIds.push(randomId);
          }
        }
        
        // Add active abilities
        for (let j = 0; j < config.activeCount && activeAbilities.length > 0; j++) {
          const randomId = activeAbilities[Math.floor(Math.random() * activeAbilities.length)];
          if (!activeIds.includes(randomId)) {
            activeIds.push(randomId);
          }
        }
        
        // Add ultimate if applicable
        if (config.ultimateCount > 0 && ultimateAbilities.length > 0) {
          const randomId = ultimateAbilities[Math.floor(Math.random() * ultimateAbilities.length)];
          if (!activeIds.includes(randomId)) {
            activeIds.push(randomId);
          }
        }
        
        // Ensure at least one active ability
        if (activeIds.length === 0 && activeAbilities.length > 0) {
          activeIds.push(activeAbilities[0]);
        }
        
        // Generate the base pet
        const basePet = generateBasePet(family, rarity, petIndex, {
          activeIds,
          passiveIds,
        });
        
        await basePetRepository.save(basePet);
        totalSeeded++;
        petIndex++;
      }
    }
  }
  
  console.log(`[SeedService] Seeded ${totalSeeded} base pets`);
}

/**
 * Seed starter stones for the player
 */
async function seedStarterStones(): Promise<void> {
  console.log('[SeedService] Seeding starter stones...');
  const stoneRepository = new StoneRepository();
  
  const stoneTypes = Object.values(StoneType);
  const starterStones = [
    // Give player one of each stone type at Tier I
    ...stoneTypes.map(type => StoneGenerator.generateStone(type, StoneTier.I)),
    // Give a few Tier II stones
    StoneGenerator.generateStone(StoneType.RUBY, StoneTier.II),
    StoneGenerator.generateStone(StoneType.SAPPHIRE, StoneTier.II),
    StoneGenerator.generateStone(StoneType.EMERALD, StoneTier.II),
  ];
  
  for (const stone of starterStones) {
    await stoneRepository.save(stone);
  }
  
  console.log(`[SeedService] Seeded ${starterStones.length} starter stones`);
}

/**
 * Seed initial player data with starter essence
 */
async function seedPlayer(): Promise<void> {
  console.log('[SeedService] Seeding player data...');
  const playerRepository = new PlayerRepository();
  
  const playerExists = await playerRepository.exists('player_1');
  if (playerExists) {
    console.log('[SeedService] Player already exists, skipping player seed');
    return;
  }
  
  // Create player with starter essence
  const starterEssence: Record<Rarity, number> = {
    [Rarity.BASIC]: 100,
    [Rarity.RARE]: 50,
    [Rarity.SR]: 20,
    [Rarity.LEGENDARY]: 5,
    [Rarity.MYTHIC]: 0,
    [Rarity.PRISMATIC]: 0,
    [Rarity.OMEGA]: 0,
  };
  
  const { Player } = await import('@/domain/entities/Player');
  const defaultPlayer = new Player(
    'player_1',
    'Player',
    starterEssence,
    1000, // Starting rank
    [], // teams
    [], // completedDungeons
    Date.now()
  );
  
  await playerRepository.save(defaultPlayer);
  console.log('[SeedService] Seeded player data');
}

/**
 * Main seed function
 */
export async function seedDatabase(): Promise<void> {
  try {
    console.log('[SeedService] Starting database seeding...');
    
    // Check if already seeded
    const needsSeed = await needsSeeding();
    if (!needsSeed) {
      console.log('[SeedService] Database already seeded, skipping');
      return;
    }
    
    // Seed abilities first (base pets need ability IDs)
    const abilityMap = await seedAbilities();
    
    // Seed base pets
    await seedBasePets(abilityMap);
    
    // Seed starter stones
    await seedStarterStones();
    
    // Seed player
    await seedPlayer();
    
    // Mark as seeded
    const db = await openDatabase();
    // Use sprites store to store seed version (it's just metadata)
    // In a real implementation, you might want a separate metadata store
    await db.put('sprites', { id: SEED_VERSION_KEY, seedVersion: CURRENT_SEED_VERSION, spriteData: '' } as any);
    
    console.log('[SeedService] Database seeding completed successfully!');
  } catch (error) {
    console.error('[SeedService] Error seeding database:', error);
    throw error;
  }
}


/**
 * Execute Turn Use Case
 * Executes a single turn in a battle
 */

import { Battle } from '@/domain/entities/Battle';
import { CombatEngine } from '@/domain/services/CombatEngine';
import type { IBattleRepository } from '@/domain/repositories/IBattleRepository';

export interface ExecuteTurnInput {
  battleId: string;
}

export interface ExecuteTurnOutput {
  battle: Battle;
  turnCompleted: boolean;
}

/**
 * Execute Turn Use Case
 */
export class ExecuteTurn {
  constructor(private battleRepository: IBattleRepository) {}

  async execute(input: ExecuteTurnInput): Promise<ExecuteTurnOutput> {
    // Fetch battle
    const battle = await this.battleRepository.findById(input.battleId as any);

    if (!battle) {
      throw new Error(`Battle not found: ${input.battleId}`);
    }

    if (battle.isComplete) {
      return {
        battle,
        turnCompleted: false,
      };
    }

    // Execute turn using CombatEngine
    const updatedBattle = CombatEngine.executeTurn(battle);

    // Save updated battle state
    await this.battleRepository.save(updatedBattle);

    return {
      battle: updatedBattle,
      turnCompleted: true,
    };
  }
}













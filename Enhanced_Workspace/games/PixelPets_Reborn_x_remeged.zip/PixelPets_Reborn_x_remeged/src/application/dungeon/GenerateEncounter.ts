/**
 * Generate Encounter Use Case
 * Converts dungeon waves/boss into combat-ready pet teams
 */

import type { Dungeon, MinionWave } from '@/domain/entities/Dungeon';
import { Pet } from '@/domain/entities/Pet';
import type { BasePet } from '@/domain/entities/BasePet';
import type { IAbilityRepository } from '@/domain/repositories/IAbilityRepository';
import { AbilityRepository } from '@/infrastructure/persistence/repositories/AbilityRepository';
import { Stats } from '@/domain/valueObjects/Stats';
import { generatePetId } from '@/shared/utils/idGenerator';
import { brandBasePetId } from '@/shared/types/brands';

export interface GenerateEncounterInput {
  dungeon: Dungeon;
  waveIndex: number;
}

export interface GenerateEncounterOutput {
  enemyPets: Pet[];
  isBoss: boolean;
}

/**
 * Generate Encounter Use Case
 */
export class GenerateEncounter {
  private abilityRepository: IAbilityRepository;

  constructor(abilityRepository?: IAbilityRepository) {
    this.abilityRepository = abilityRepository || new AbilityRepository();
  }

  async execute(input: GenerateEncounterInput): Promise<GenerateEncounterOutput> {
    const { dungeon, waveIndex } = input;

    // Check if this is the boss encounter
    const isBoss = waveIndex >= dungeon.minionWaves.length;

    if (isBoss) {
      // Generate boss encounter
      const bossPet = await this.convertBasePetToPet(
        dungeon.boss.pet,
        dungeon.boss.difficultyMultiplier
      );
      return {
        enemyPets: [bossPet, bossPet, bossPet, bossPet], // Boss fills all 4 slots
        isBoss: true,
      };
    } else {
      // Generate minion wave
      const wave: MinionWave = dungeon.minionWaves[waveIndex];
      const enemyPets: Pet[] = [];

      // Convert base pets to combat pets, applying difficulty scaling
      for (const basePet of wave.pets) {
        const pet = await this.convertBasePetToPet(basePet, 1.0); // Minions use base stats
        enemyPets.push(pet);
      }

      // Fill remaining slots with duplicates of the first pet if needed (to reach 4 pets)
      while (enemyPets.length < 4) {
        const firstPet = enemyPets[0];
        if (firstPet) {
          // Create a duplicate with a new ID
          const duplicate = await this.convertBasePetToPet(
            dungeon.minionWaves[waveIndex].pets[0],
            1.0
          );
          enemyPets.push(duplicate);
        } else {
          break;
        }
      }

      return {
        enemyPets: enemyPets.slice(0, 4), // Ensure exactly 4 pets
        isBoss: false,
      };
    }
  }

  /**
   * Convert a BasePet to a Pet entity for combat
   * Applies difficulty multiplier to stats
   */
  private async convertBasePetToPet(
    basePet: BasePet,
    difficultyMultiplier: number
  ): Promise<Pet> {
    // Calculate scaled stats
    const scaledHp = Math.round(basePet.baseStats.hp * difficultyMultiplier);
    const scaledAttack = Math.round(basePet.baseStats.attack * difficultyMultiplier);
    const scaledDefense = Math.round(basePet.baseStats.defense * difficultyMultiplier);
    // Speed typically doesn't scale with difficulty
    const speed = basePet.baseStats.speed;

    const stats = Stats.create(scaledHp, scaledHp, scaledAttack, scaledDefense, speed);

    // Load abilities from IDs
    const passiveAbilities = [];
    const activeAbilities = [];
    let ultimateAbility = null;

    // Load passive abilities
    for (const abilityId of basePet.starterPassives) {
      const ability = await this.abilityRepository.findById(abilityId as any);
      if (ability && ability.type === 'passive') {
        passiveAbilities.push(ability);
      }
    }

    // Load active abilities
    for (const abilityId of basePet.starterAbilities) {
      const ability = await this.abilityRepository.findById(abilityId as any);
      if (ability) {
        if (ability.type === 'active') {
          activeAbilities.push(ability);
        } else if (ability.type === 'ultimate') {
          ultimateAbility = ability;
        }
      }
    }

    // Ensure at least one active ability (create a basic attack if none found)
    if (activeAbilities.length === 0) {
      // For now, we'll throw an error - in production, you might want to create a default ability
      throw new Error(`Base pet ${basePet.name} has no active abilities`);
    }

    // Create pet entity
    return new Pet(
      generatePetId(),
      brandBasePetId(basePet.id),
      basePet.name,
      null, // nickname
      basePet.family,
      basePet.rarity,
      stats,
      passiveAbilities,
      activeAbilities,
      ultimateAbility,
      [], // fusionHistory - dungeon enemies are not fused
      {
        visualTags: [...basePet.visualTags],
      },
      null, // battleStats - new combat instance
      Date.now(), // collectionDate
      basePet.lore // lore from base pet
    );
  }
}


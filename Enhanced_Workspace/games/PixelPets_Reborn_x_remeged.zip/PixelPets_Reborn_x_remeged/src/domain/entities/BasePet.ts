/**
 * BasePet Entity
 * Template for summonable pets (not runtime instances)
 */

import type { BasePetId } from '@/shared/types/brands';
import type { Rarity } from '@/shared/types/rarity';
import type { PetFamily } from '@/shared/types/family';

export interface BasePetStats {
  hp: number;
  attack: number;
  defense: number;
  speed: number;
}

export class BasePet {
  constructor(
    public readonly id: BasePetId,
    public readonly name: string,
    public readonly family: PetFamily,
    public readonly rarity: Rarity,
    public readonly baseStats: BasePetStats,
    public readonly starterAbilities: readonly string[],
    public readonly starterPassives: readonly string[],
    public readonly visualTags: readonly string[],
    public readonly lore: string
  ) {
    this.validate();
  }

  private validate(): void {
    if (!this.id) throw new Error('BasePet must have an ID');
    if (!this.name) throw new Error('BasePet must have a name');
    if (!this.lore) throw new Error('BasePet must have lore');
    if (this.baseStats.hp <= 0) throw new Error('BasePet HP must be positive');
    if (this.baseStats.attack < 0) throw new Error('BasePet attack cannot be negative');
    if (this.baseStats.defense < 0) throw new Error('BasePet defense cannot be negative');
    if (this.baseStats.speed < 0) throw new Error('BasePet speed cannot be negative');
  }
}
















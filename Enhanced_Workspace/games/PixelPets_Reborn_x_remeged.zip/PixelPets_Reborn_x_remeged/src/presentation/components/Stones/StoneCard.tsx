/**
 * Stone Card Component
 * Reusable component for displaying stone information
 */

import React from 'react';
import type { Stone } from '@/domain/entities/Stone';
import { StoneType, StoneTier } from '@/domain/entities/Stone';
import './StoneCard.css';

export interface StoneCardProps {
  stone: Stone;
  onClick?: () => void;
  selected?: boolean;
}

export const StoneCard: React.FC<StoneCardProps> = ({
  stone,
  onClick,
  selected = false,
}) => {
  const selectedClass = selected ? 'stone-card--selected' : '';

  const tierNames: Record<StoneTier, string> = {
    [StoneTier.I]: 'I',
    [StoneTier.II]: 'II',
    [StoneTier.III]: 'III',
    [StoneTier.IV]: 'IV',
    [StoneTier.V]: 'V',
  };

  const typeColors: Record<StoneType, string> = {
    [StoneType.RUBY]: '#FF4444',
    [StoneType.SAPPHIRE]: '#4444FF',
    [StoneType.EMERALD]: '#44FF44',
    [StoneType.TOPAZ]: '#FFAA44',
    [StoneType.AMETHYST]: '#AA44FF',
    [StoneType.PEARL]: '#FFFFFF',
    [StoneType.ONYX]: '#000000',
    [StoneType.OPAL]: '#FF00FF',
  };

  return (
    <div
      className={`stone-card ${selectedClass}`}
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          onClick?.();
        }
      }}
    >
      <div
        className="stone-card__type-bar"
        style={{ backgroundColor: typeColors[stone.type] }}
      />
      <div className="stone-card__content">
        <div className="stone-card__header">
          <h3 className="stone-card__type">{stone.type}</h3>
          <div className="stone-card__tier">Tier {tierNames[stone.tier]}</div>
        </div>
        {stone.isGlitched && (
          <div className="stone-card__glitched">GLITCHED</div>
        )}
        <div className="stone-card__stats">
          <div className="stone-card__stat">
            <span className="stone-card__stat-label">HP:</span>
            <span className="stone-card__stat-value">
              {stone.statBonuses.hp > 0 ? '+' : ''}
              {stone.statBonuses.hp}
            </span>
          </div>
          <div className="stone-card__stat">
            <span className="stone-card__stat-label">ATK:</span>
            <span className="stone-card__stat-value">
              {stone.statBonuses.attack > 0 ? '+' : ''}
              {stone.statBonuses.attack}
            </span>
          </div>
          <div className="stone-card__stat">
            <span className="stone-card__stat-label">DEF:</span>
            <span className="stone-card__stat-value">
              {stone.statBonuses.defense > 0 ? '+' : ''}
              {stone.statBonuses.defense}
            </span>
          </div>
          <div className="stone-card__stat">
            <span className="stone-card__stat-label">SPD:</span>
            <span className="stone-card__stat-value">
              {stone.statBonuses.speed > 0 ? '+' : ''}
              {stone.statBonuses.speed}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};




/**
 * Summon View Component
 * Allows players to summon new pets from base pet templates
 */

import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { SummonPet } from '@/application/summon/SummonPet';
import { PetRepository } from '@/infrastructure/persistence/repositories/PetRepository';
import { BasePetRepository } from '@/infrastructure/persistence/repositories/BasePetRepository';
import { AbilityRepository } from '@/infrastructure/persistence/repositories/AbilityRepository';
import { PlayerRepository } from '@/infrastructure/persistence/repositories/PlayerRepository';
import { usePetStore } from '../../stores/petStore';
import { usePlayerStore } from '../../stores/playerStore';
import { Button } from '../common/Button';
import { Card } from '../common/Card';
import { Modal } from '../common/Modal';
import { ToastContainer } from '../common/Toast';
import { Rarity, RARITY_CONFIG } from '@/shared/types/rarity';
import { PetFamily, FAMILY_CONFIGS } from '@/shared/types/family';
import type { BasePet } from '@/domain/entities/BasePet';
import './SummonView.css';

interface ToastItem {
  id: string;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
}

export const SummonView: React.FC = () => {
  const navigate = useNavigate();
  const { loadPets } = usePetStore();
  const { player, loadPlayer } = usePlayerStore();
  const [basePets, setBasePets] = useState<BasePet[]>([]);
  const [filteredPets, setFilteredPets] = useState<BasePet[]>([]);
  const [selectedRarity, setSelectedRarity] = useState<Rarity | 'all'>('all');
  const [selectedFamily, setSelectedFamily] = useState<PetFamily | 'all'>('all');
  const [selectedPet, setSelectedPet] = useState<BasePet | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [isSummoning, setIsSummoning] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  // Initialize repositories and use case
  const summonPetUseCase = useMemo(
    () =>
      new SummonPet(
        new PetRepository(),
        new BasePetRepository(),
        new AbilityRepository(),
        new PlayerRepository()
      ),
    []
  );

  // Load base pets and player on mount
  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        const repository = new BasePetRepository();
        const allBasePets = await repository.findAll();
        setBasePets(allBasePets);
        setFilteredPets(allBasePets);
        await loadPlayer();
      } catch (error) {
        console.error('Error loading data:', error);
        addToast('Failed to load data', 'error');
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [loadPlayer]);

  // Filter base pets by rarity and family
  useEffect(() => {
    let filtered = [...basePets];

    if (selectedRarity !== 'all') {
      filtered = filtered.filter((pet) => pet.rarity === selectedRarity);
    }

    if (selectedFamily !== 'all') {
      filtered = filtered.filter((pet) => pet.family === selectedFamily);
    }

    setFilteredPets(filtered);
  }, [basePets, selectedRarity, selectedFamily]);

  const addToast = (message: string, type: ToastItem['type'] = 'info') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((toast) => toast.id !== id));
    }, 5000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  };

  const handleSummonClick = (pet: BasePet) => {
    setSelectedPet(pet);
    setShowConfirmModal(true);
  };

  const handleConfirmSummon = async () => {
    if (!selectedPet || !player) return;

    try {
      setIsSummoning(true);
      const result = await summonPetUseCase.execute({
        basePetId: selectedPet.id,
        playerId: player.id,
      });

      addToast(result.message, 'success');
      await loadPets(); // Refresh pet collection
      await loadPlayer(); // Refresh player data (essence consumed)
      setShowConfirmModal(false);
      setSelectedPet(null);

      // Navigate to collection after a short delay
      setTimeout(() => {
        navigate('/collection');
      }, 1500);
    } catch (error) {
      console.error('Error summoning pet:', error);
      addToast(
        error instanceof Error ? error.message : 'Failed to summon pet',
        'error'
      );
    } finally {
      setIsSummoning(false);
    }
  };

  if (isLoading) {
    return (
      <div className="summon-view">
        <div className="summon-view__loading">Loading available pets...</div>
      </div>
    );
  }

  return (
    <div className="summon-view">
      <ToastContainer toasts={toasts} onRemove={removeToast} />

      <div className="summon-view__header">
        <h1>Summon Pet</h1>
        <p>Choose a pet to add to your collection</p>
        {player && (
          <div className="summon-view__essence-balance">
            <h3>Essence Balance</h3>
            <div className="summon-view__essence-list">
              {Object.entries(RARITY_CONFIG).map(([key, config]) => {
                const rarity = parseInt(key) as Rarity;
                const amount = player.essence[rarity];
                return (
                  <div key={key} className="summon-view__essence-item">
                    <span className="summon-view__essence-name" style={{ color: config.color }}>
                      {config.name}:
                    </span>
                    <span className="summon-view__essence-amount">{amount}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      <div className="summon-view__filters">
        <div className="summon-view__filter-group">
          <label htmlFor="rarity-filter">Rarity:</label>
          <select
            id="rarity-filter"
            value={selectedRarity}
            onChange={(e) => setSelectedRarity(e.target.value as Rarity | 'all')}
            className="summon-view__select"
          >
            <option value="all">All Rarities</option>
            {Object.entries(RARITY_CONFIG).map(([key, config]) => (
              <option key={key} value={key}>
                {config.name}
              </option>
            ))}
          </select>
        </div>

        <div className="summon-view__filter-group">
          <label htmlFor="family-filter">Family:</label>
          <select
            id="family-filter"
            value={selectedFamily}
            onChange={(e) =>
              setSelectedFamily(e.target.value as PetFamily | 'all')
            }
            className="summon-view__select"
          >
            <option value="all">All Families</option>
            {Object.entries(FAMILY_CONFIGS).map(([key, config]) => (
              <option key={key} value={key}>
                {config.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {filteredPets.length === 0 ? (
        <div className="summon-view__empty">
          <p>No pets available matching your filters.</p>
        </div>
      ) : (
        <div className="summon-view__grid">
          {filteredPets.map((pet) => {
            const rarityConfig = RARITY_CONFIG[pet.rarity];
            const familyConfig = FAMILY_CONFIGS[pet.family];

            return (
              <Card key={pet.id} className="summon-view__pet-card">
                <div className="summon-view__pet-header">
                  <h3 className="summon-view__pet-name">{pet.name}</h3>
                  <div
                    className="summon-view__pet-rarity"
                    style={{ color: rarityConfig.color }}
                  >
                    {rarityConfig.name}
                  </div>
                </div>

                <div className="summon-view__pet-family">
                  Family: {familyConfig.name}
                </div>

                <div className="summon-view__pet-stats">
                  <div className="summon-view__stat">
                    <span>HP:</span>
                    <span>{pet.baseStats.hp}</span>
                  </div>
                  <div className="summon-view__stat">
                    <span>ATK:</span>
                    <span>{pet.baseStats.attack}</span>
                  </div>
                  <div className="summon-view__stat">
                    <span>DEF:</span>
                    <span>{pet.baseStats.defense}</span>
                  </div>
                  <div className="summon-view__stat">
                    <span>SPD:</span>
                    <span>{pet.baseStats.speed}</span>
                  </div>
                </div>

                {pet.lore && (
                  <div className="summon-view__pet-lore">{pet.lore}</div>
                )}

                <div className="summon-view__pet-cost">
                  <span className="summon-view__cost-label">Cost:</span>
                  <span
                    className="summon-view__cost-amount"
                    style={{ color: rarityConfig.color }}
                  >
                    {rarityConfig.summonCost} {rarityConfig.name} Essence
                  </span>
                  {player && player.essence[pet.rarity] < rarityConfig.summonCost && (
                    <div className="summon-view__insufficient-essence">
                      Insufficient essence
                    </div>
                  )}
                </div>

                <Button
                  onClick={() => handleSummonClick(pet)}
                  className="summon-view__summon-button"
                  fullWidth
                  disabled={player ? player.essence[pet.rarity] < rarityConfig.summonCost : false}
                >
                  Summon
                </Button>
              </Card>
            );
          })}
        </div>
      )}

      {/* Confirm Summon Modal */}
      {showConfirmModal && selectedPet && (
        <Modal
          isOpen={showConfirmModal}
          onClose={() => {
            setShowConfirmModal(false);
            setSelectedPet(null);
          }}
          title={`Summon ${selectedPet.name}?`}
        >
          <div className="summon-view__confirm-modal">
            <p>
              Are you sure you want to summon <strong>{selectedPet.name}</strong>?
            </p>
            {player && (
              <div className="summon-view__confirm-cost">
                <p>
                  Cost: <strong style={{ color: RARITY_CONFIG[selectedPet.rarity].color }}>
                    {RARITY_CONFIG[selectedPet.rarity].summonCost} {RARITY_CONFIG[selectedPet.rarity].name} Essence
                  </strong>
                </p>
                <p>
                  Your balance: <strong>{player.essence[selectedPet.rarity]}</strong> {RARITY_CONFIG[selectedPet.rarity].name} Essence
                </p>
              </div>
            )}
            <p className="summon-view__confirm-note">
              Note: You can only own one of each base pet at a time. You must
              fuse it before you can summon another.
            </p>
            <div className="summon-view__confirm-actions">
              <Button
                variant="secondary"
                onClick={() => {
                  setShowConfirmModal(false);
                  setSelectedPet(null);
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleConfirmSummon}
                disabled={isSummoning}
                loading={isSummoning}
              >
                Summon
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};


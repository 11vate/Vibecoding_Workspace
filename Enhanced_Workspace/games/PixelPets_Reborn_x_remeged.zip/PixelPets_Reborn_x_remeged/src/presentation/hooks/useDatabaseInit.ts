/**
 * Database Initialization Hook
 * Initializes the database on app start if needed
 */

import { useEffect, useState } from 'react';
import { seedDatabase, needsSeeding } from '@/infrastructure/content/SeedService';

export function useDatabaseInit(): { isInitializing: boolean; isInitialized: boolean; error: string | null } {
  const [isInitializing, setIsInitializing] = useState(true);
  const [isInitialized, setIsInitialized] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    async function initDatabase() {
      try {
        setIsInitializing(true);
        setError(null);

        const needsSeed = await needsSeeding();
        if (needsSeed) {
          console.log('[useDatabaseInit] Database needs seeding, initializing...');
          await seedDatabase();
          if (isMounted) {
            setIsInitialized(true);
          }
        } else {
          console.log('[useDatabaseInit] Database already initialized');
          if (isMounted) {
            setIsInitialized(true);
          }
        }
      } catch (err) {
        console.error('[useDatabaseInit] Error initializing database:', err);
        if (isMounted) {
          setError(err instanceof Error ? err.message : 'Failed to initialize database');
        }
      } finally {
        if (isMounted) {
          setIsInitializing(false);
        }
      }
    }

    initDatabase();

    return () => {
      isMounted = false;
    };
  }, []);

  return { isInitializing, isInitialized, error };
}




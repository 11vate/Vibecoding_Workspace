# Pixel Pets Reborn x Remeged

Complete redesign and rearchitecture of Pixel Pets Reborn with enhanced features, improved architecture, and expanded content.

## Description

Pixel Pets Reborn x Remeged is a mobile-first Progressive Web App (PWA) featuring AI-driven pet fusion, strategic battles, and an extensive collection system. This version represents a complete rebuild from the ground up with:

- **Hexagonal Architecture** - Clean separation of concerns
- **Expanded Content** - 150 fully designed base pets, 200+ abilities
- **Enhanced Systems** - Comprehensive fusion signatures, glitched stones, duplicate prevention
- **Improved Balance** - Refined formulas and progression curves

## Key Features

- **150 Base Pets** across 10 families (fully designed with unique lore and signature abilities)
- **200+ Abilities** with comprehensive coverage across all elements
- **AI-Powered Fusion** using Ollama (with procedural fallback)
- **8 Stone Types** with 5 tiers, glitched variants, and comprehensive lore
- **Combat System** with smart AI and domain effects
- **Offline-First** with IndexedDB storage
- **PWA** - Installable on mobile and desktop

## Tech Stack

- React 19 + TypeScript 5.9+
- Vite 7
- Zustand 5 (state management)
- React Router 7 (routing)
- IndexedDB (via idb library)
- Ollama (local LLM for AI fusion)
- Zod (runtime validation)
- Vitest (testing)

## Development

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Run tests
npm test
```

## Project Structure

```
src/
├── domain/                   # Domain layer (business logic)
│   ├── entities/            # Core entities (Pet, Stone, etc.)
│   ├── valueObjects/        # Value objects (Stats, Rarity, etc.)
│   ├── repositories/        # Repository interfaces
│   └── services/            # Domain services
├── application/              # Application layer (use cases)
│   ├── fusion/              # Fusion use cases
│   ├── combat/              # Combat use cases
│   ├── dungeon/             # Dungeon use cases
│   └── collection/          # Collection use cases
├── infrastructure/           # Infrastructure layer
│   ├── persistence/         # Database implementations
│   ├── ai/                  # AI service implementations
│   ├── sprites/             # Sprite generation
│   └── events/              # Event system
├── presentation/             # Presentation layer
│   ├── components/          # React components
│   ├── hooks/               # React hooks
│   ├── stores/              # State management (Zustand)
│   └── routes/              # Routing configuration
└── shared/                   # Shared utilities
    ├── types/               # Shared TypeScript types
    ├── utils/               # Utility functions
    └── constants/           # Constants and configs
```

## Architecture

This project uses **Hexagonal Architecture** (ports and adapters) with clear separation between:

- **Domain Layer**: Business logic and entities (no dependencies on infrastructure)
- **Application Layer**: Use cases and application services
- **Infrastructure Layer**: Technical implementations (database, AI, sprites)
- **Presentation Layer**: UI components and state management

## AI Fusion

The game uses Ollama (local LLM) for AI-powered pet fusion. If Ollama is not available, it falls back to procedural generation.

### Setting up Ollama

1. Install Ollama from https://ollama.ai
2. Pull a model: `ollama pull llama3.2`
3. Start Ollama service
4. The game will automatically detect and use Ollama when available

## License

ISC















